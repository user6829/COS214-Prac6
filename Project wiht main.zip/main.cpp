/**
 * @file main.cpp
 * @brief Interactive TUI: South African University Admissions, driven by the
 *        generic TIVIDY workflow engine (COS214 Practical 6).
 *
 * Demonstrates that the SAME generic engine (unmodified) can drive a real
 * South African university admissions scenario across BOTH industries:
 *
 *   Informational industry  ->  Admissions Office   (undergraduate)
 *   Transactional industry  ->  Faculty Board       (postgraduate)
 *
 * South African metrics used:
 *   - APS (Admission Point Score), out of 42 (6 subjects x 7)
 *   - NSC English achievement level, 1 - 7
 *      7 = 80-100%, 6 = 70-79%, 5 = 60-69%, 4 = 50-59% (Bachelor's pass min),
 *      3 = 40-49%, 2 = 30-39%, 1 = 0-29%
 *
 * Routing on APS:
 *   APS >= highApsThreshold  ->  senior-reviewer
 *   APS <  highApsThreshold  ->  admissions-officer
 *
 * Requirement coverage (Section 5):
 *   - Start an instance               -> menu 1
 *   - Inspect available work          -> menu 2
 *   - Take actions                    -> menus 3, 4
 *   - Observe routing & state changes -> observers attached on start
 *   - View history                    -> menu 5
 *   - Use both industries             -> menus 1, 6
 *   - Realistic test data             -> seeded definitions
 *   - Error handling                  -> every engine call wrapped in try/catch
 */

#include <iostream>
#include <iomanip>
#include <string>
#include <map>
#include <sstream>
#include <memory>
#include <vector>

// Engine
#include "TividyEngineFacade.h"
#include "WorkflowDefinition.h"
#include "WorkflowInstance.h"
#include "WorkflowContext.h"
#include "WorkflowComponent.h"
#include "CompositeStage.h"
#include "LeafWorkItem.h"

// State / routing / approval
#include "WorkItemState.h"
#include "ActiveState.h"
#include "InactiveState.h"
#include "CompletedState.h"
#include "RejectedState.h"
#include "RoutingStrategy.h"
#include "RoleBasedRouting.h"
#include "ValueThresholdRouting.h"
#include "ApprovalHandler.h"
#include "HandlerA.h"
#include "HandlerB.h"

// Observers
#include "EventObserver.h"
#include "NotificationObserver.h"
#include "StateObserver.h"
#include "AuditLoggerObserver.h"

// History
#include "AuditCaretaker.h"
#include "WorkflowMemento.h"

// Visitor
#include "WorkflowVisitor.h"
#include "MetricsReportVisitor.h"

// Documents (both industries)
#include "Document.h"
#include "DocumentFactory.h"
#include "InformationalFactory.h"
#include "TransactionalFactory.h"

// Adapter
#include "ExternalSystemConnector.h"
#include "LegacyiHookAdapter.h"
#include "LegacyiHookAPI.h"

// =============================================================================
// Globals
// =============================================================================
static TividyEngineFacade gEngine;
static std::vector<EventObserver *> gObservers;

// =============================================================================
// I/O helpers
// =============================================================================
static void rule() { std::cout << "------------------------------------------------------------\n"; }
static void heading(const std::string &s)
{
    rule();
    std::cout << s << "\n";
    rule();
}

static std::string ask(const std::string &prompt)
{
    std::cout << prompt;
    std::string s;
    std::getline(std::cin, s);
    if (!s.empty() && s[s.size() - 1] == '\r')
        s.erase(s.size() - 1);
    return s;
}

static int askInt(const std::string &prompt)
{
    std::string s = ask(prompt);
    std::istringstream iss(s);
    int v = -1;
    if (!(iss >> v))
        return -1;
    return v;
}

// =============================================================================
// Build a South African university workflow definition.
// =============================================================================
static WorkflowDefinition *buildUniversityDefinition(const std::string &industry,
                                                     const std::string &defId,
                                                     const std::string &programme,
                                                     double highApsThreshold)
{
    CompositeStage *root = new CompositeStage(defId + "-root",
                                              industry + ": " + programme + " admissions");

    // -------------------------------------------------------------------------
    // Stage 1 — Intake
    // -------------------------------------------------------------------------
    CompositeStage *intake = new CompositeStage(defId + "-intake", "Intake");

    LeafWorkItem *submitApp = new LeafWorkItem(defId + "-submit",
                                               "Submit application form");
    LeafWorkItem *payFee = new LeafWorkItem(defId + "-payfee",
                                            "Pay application fee");

    submitApp->setState(new ActiveState());
    payFee->setState(new InactiveState());

    submitApp->setRoutingStrategy(new RoleBasedRouting("applicant"));
    payFee->setRoutingStrategy(new RoleBasedRouting("fee-collector"));

    HandlerA<std::string> *feeReviewer = new HandlerA<std::string>();
    payFee->setApprovalHandler(feeReviewer);

    intake->add(std::shared_ptr<WorkflowComponent>(submitApp));
    intake->add(std::shared_ptr<WorkflowComponent>(payFee));

    // -------------------------------------------------------------------------
    // Stage 2 — Academic Screening (APS + English)
    // -------------------------------------------------------------------------
    CompositeStage *screening = new CompositeStage(defId + "-screening",
                                                   "Academic Screening");

    LeafWorkItem *reviewAps = new LeafWorkItem(defId + "-aps",
                                               "Review APS and matric results");
    reviewAps->setState(new ActiveState());

    reviewAps->setRoutingStrategy(new ValueThresholdRouting(
        "aps", highApsThreshold, "admissions-officer", "senior-reviewer"));

    HandlerA<std::string> *apsReviewer = new HandlerA<std::string>();
    HandlerB<std::string> *apsEscalator = new HandlerB<std::string>();
    apsReviewer->setNext(apsEscalator);
    reviewAps->setApprovalHandler(apsReviewer);

    LeafWorkItem *englishCheck = new LeafWorkItem(defId + "-english",
                                                  "Verify NSC English achievement (level 4 minimum)");
    englishCheck->setState(new InactiveState());
    englishCheck->setRoutingStrategy(new RoleBasedRouting("language-reviewer"));

    screening->add(std::shared_ptr<WorkflowComponent>(reviewAps));
    screening->add(std::shared_ptr<WorkflowComponent>(englishCheck));

    // -------------------------------------------------------------------------
    // Stage 3 — Offer / Decision
    // -------------------------------------------------------------------------
    CompositeStage *offer = new CompositeStage(defId + "-offer",
                                               "Offer Decision");

    LeafWorkItem *issueOffer = new LeafWorkItem(defId + "-offer",
                                                "Issue offer of admission or rejection");
    issueOffer->setState(new InactiveState());
    issueOffer->setRoutingStrategy(new RoleBasedRouting("faculty-board"));

    HandlerA<std::string> *offerReviewer = new HandlerA<std::string>();
    HandlerB<std::string> *offerEscalator = new HandlerB<std::string>();
    offerReviewer->setNext(offerEscalator);
    issueOffer->setApprovalHandler(offerReviewer);

    offer->add(std::shared_ptr<WorkflowComponent>(issueOffer));

    // -------------------------------------------------------------------------
    // Assemble
    // -------------------------------------------------------------------------
    root->add(std::shared_ptr<WorkflowComponent>(intake));
    root->add(std::shared_ptr<WorkflowComponent>(screening));
    root->add(std::shared_ptr<WorkflowComponent>(offer));

    WorkflowDefinition *def = new WorkflowDefinition(defId, industry);
    def->setRootElement(root);
    return def;
}

// =============================================================================
// Seed both industries
// =============================================================================
static void seedDefinitions()
{
    heading("Seeding university workflow definitions");

    gEngine.registerDefinition("undergraduate-admissions",
                               buildUniversityDefinition("informational",
                                                         "undergrad",
                                                         "BSc Computer Science",
                                                         35.0)); // APS >= 35 -> senior-reviewer

    gEngine.registerDefinition("postgraduate-admissions",
                               buildUniversityDefinition("transactional",
                                                         "postgrad",
                                                         "MSc Data Science",
                                                         38.0)); // APS >= 38 -> senior-reviewer

    std::cout << "  undergraduate-admissions  (informational industry)\n"
              << "  postgraduate-admissions   (transactional industry)\n";
}

// =============================================================================
// Walk the definition tree
// =============================================================================
static void walk(WorkflowComponent *node, int depth)
{
    if (!node)
        return;
    std::string indent(depth * 2, ' ');

    CompositeStage *stage = dynamic_cast<CompositeStage *>(node);
    if (stage)
    {
        std::cout << indent << "[Stage] " << stage->getName()
                  << "  (" << stage->getId() << ")\n";
        const std::vector<std::shared_ptr<WorkflowComponent>> &kids =
            stage->getChildren();
        for (size_t i = 0; i < kids.size(); ++i)
            walk(kids[i].get(), depth + 1);
        return;
    }

    LeafWorkItem *leaf = dynamic_cast<LeafWorkItem *>(node);
    if (leaf)
    {
        std::cout << indent << "[Work item] " << leaf->getName()
                  << "  (" << leaf->getId() << ")\n";

        WorkItemState *st = leaf->getCurrentState();
        std::cout << indent << "    state:   "
                  << (st ? st->getStateName() : std::string("none")) << "\n";

        RoutingStrategy *rs = leaf->getRoutingStrategy();
        if (rs)
        {
            try
            {
                std::cout << indent << "    routes to: "
                          << rs->determineAssignee(*leaf) << "\n";
            }
            catch (const std::exception &e)
            {
                std::cout << indent << "    routing note: " << e.what() << "\n";
            }
        }
    }
}

// =============================================================================
// Print step ids for a chosen workflow
// =============================================================================
static void printStepIds(const std::string &prefix)
{
    std::cout << "  " << prefix << "-submit      Submit application form\n"
              << "  " << prefix << "-payfee      Pay application fee\n"
              << "  " << prefix << "-aps         Review APS and matric results\n"
              << "  " << prefix << "-english     Verify NSC English level\n"
              << "  " << prefix << "-offer       Issue offer / rejection\n";
}

// =============================================================================
// Menu 1 — Start a new application
// =============================================================================
static void menuStart()
{
    heading("Start a new application");

    std::cout << "Which admissions workflow?\n"
              << "  1. Undergraduate (informational industry)\n"
              << "  2. Postgraduate  (transactional industry)\n";
    int flow = askInt("Choose: ");

    std::string defId;
    std::string prefix;
    if (flow == 1)
    {
        defId = "undergraduate-admissions";
        prefix = "undergrad";
    }
    else if (flow == 2)
    {
        defId = "postgraduate-admissions";
        prefix = "postgrad";
    }
    else
    {
        std::cout << "Invalid choice.\n";
        return;
    }

    std::map<std::string, std::string> data;
    data["studentName"] = ask("Student full name: ");
    data["studentNumber"] = ask("Student number (e.g. u24986535): ");
    data["nationality"] = ask("Nationality (South African / International): ");
    data["programme"] = ask("Degree programme (e.g. BSc Computer Science): ");
    data["aps"] = ask("APS (out of 42, e.g. 38): ");
    data["englishLevel"] = ask("NSC English level (1-7, 4=Bachelor's pass min): ");
    data["matricYear"] = ask("Matric year (e.g. 2024): ");
    data["applicationFeePaid"] = "false";
    data["State"] = "Submitted";
    data["Event"] = "Application submitted";
    data["ID"] = "";

    try
    {
        WorkflowInstance *inst = gEngine.startWorkflow(defId, data);

        if (gObservers.empty())
        {
            gObservers.push_back(new NotificationObserver());
            gObservers.push_back(new StateObserver());
            gObservers.push_back(new AuditLoggerObserver());
        }
        for (size_t i = 0; i < gObservers.size(); ++i)
            inst->attach(gObservers[i]);

        std::cout << "\n>> Application started. Instance id = "
                  << inst->getInstanceID() << "\n"
                  << "   Write this down. You'll need it for menus 2-5.\n"
                  << "   The following step ids belong to this workflow:\n";
        printStepIds(prefix);
    }
    catch (const std::exception &e)
    {
        std::cout << "Error: " << e.what() << "\n";
    }
}

// =============================================================================
// Menu 2 — Inspect an application
// =============================================================================
static void menuInspect()
{
    heading("Inspect an application");
    std::string iid = ask("Instance id (e.g. INST-1): ");

    try
    {
        WorkflowInstance *inst = gEngine.getInstance(iid);
        if (!inst)
        {
            std::cout << "No such application.\n";
            return;
        }

        WorkflowContext *ctx = inst->getContext();
        std::cout << "Instance: " << inst->getInstanceID() << "\n"
                  << "  state:  " << inst->getState() << "\n"
                  << "  event:  " << inst->getEventName() << "\n";

        if (ctx)
        {
            const std::map<std::string, std::string> &all = ctx->getAll();
            for (std::map<std::string, std::string>::const_iterator it = all.begin();
                 it != all.end(); ++it)
            {
                if (it->first == "aps")
                    std::cout << "  " << std::setw(18) << "APS" << " = "
                              << it->second << " / 42\n";
                else if (it->first == "englishLevel")
                    std::cout << "  " << std::setw(18) << "English (NSC)" << " = "
                              << it->second << " / 7\n";
                else
                    std::cout << "  " << std::setw(18) << it->first
                              << " = " << it->second << "\n";
            }
        }

        std::cout << "\nWhich workflow does this application use?\n"
                  << "  1. Undergraduate\n"
                  << "  2. Postgraduate\n";
        int flow = askInt("Choose: ");
        std::string defId;
        if (flow == 1)
            defId = "undergraduate-admissions";
        else if (flow == 2)
            defId = "postgraduate-admissions";
        else
            return;

        WorkflowDefinition *def = gEngine.getDefinition(defId);
        if (def)
        {
            rule();
            walk(def->getRootElement(), 0);
        }
    }
    catch (const std::exception &e)
    {
        std::cout << "Error: " << e.what() << "\n";
    }
}

// =============================================================================
// Menu 3 — Execute a step
// =============================================================================
static void menuExecute()
{
    heading("Take an action on an application");
    std::string iid = ask("Instance id: ");

    std::cout << "\nAvailable steps:\n"
              << "  --- Undergraduate ---\n";
    printStepIds("undergrad");
    std::cout << "  --- Postgraduate ---\n";
    printStepIds("postgrad");

    std::string sid = ask("Step id: ");
    try
    {
        gEngine.executeStep(iid, sid);
        std::cout << "Executed step: " << sid << "\n";
    }
    catch (const std::exception &e)
    {
        std::cout << "Error: " << e.what() << "\n";
    }
}

// =============================================================================
// Menu 4 — Record a decision
// =============================================================================
static void menuDecision()
{
    heading("Record an admissions decision");
    std::string iid = ask("Instance id: ");
    std::string sid = ask("Step id (e.g. undergrad-aps): ");
    std::string dec = ask("Decision (APPROVE / REJECT / WAITLIST): ");

    try
    {
        gEngine.processApproval(iid, sid, dec);
        std::cout << "Recorded decision: " << dec << "\n";
    }
    catch (const std::exception &e)
    {
        std::cout << "Error: " << e.what() << "\n";
    }
}

// =============================================================================
// Menu 5 — View / rollback history
// =============================================================================
static void menuHistory()
{
    heading("Application history");
    AuditCaretaker *care = gEngine.getAuditCaretaker();
    int n = care->size();
    std::cout << "Snapshots recorded: " << n << "\n";
    for (int i = 0; i < n; ++i)
    {
        WorkflowMemento *m = care->getSnapshot(i);
        if (!m)
            continue;
        std::cout << "  [" << i << "] " << m->getTimestamp() << "\n";
        std::map<std::string, std::string> *s = m->getState();
        if (s)
            for (std::map<std::string, std::string>::iterator it = s->begin();
                 it != s->end(); ++it)
                std::cout << "        " << it->first << " = " << it->second << "\n";
    }

    int idx = askInt("Rollback to index (-1 to cancel): ");
    if (idx >= 0)
    {
        std::string iid = ask("Instance id: ");
        try
        {
            gEngine.rollbackInstance(iid, idx);
            std::cout << "Rolled back " << iid << " to snapshot " << idx << "\n";
        }
        catch (const std::exception &e)
        {
            std::cout << "Error: " << e.what() << "\n";
        }
    }
}

// =============================================================================
// Menu 6 — Both industries: document factories
// =============================================================================
static void menuDocuments()
{
    heading("University documents — both industries");
    std::cout << "  1. Admission Conditions  (informational - non-binding)\n"
              << "  2. Applicant Guidelines  (informational)\n"
              << "  3. Offer of Admission    (transactional - binding)\n"
              << "  4. Enrolment Contract    (transactional)\n";
    int which = askInt("Choose: ");

    DocumentFactory *f = nullptr;
    std::string kind;
    switch (which)
    {
    case 1:
        f = new InformationalFactory();
        kind = "contract";
        break;
    case 2:
        f = new InformationalFactory();
        kind = "guideline";
        break;
    case 3:
        f = new TransactionalFactory();
        kind = "contract";
        break;
    case 4:
        f = new TransactionalFactory();
        kind = "guideline";
        break;
    default:
        std::cout << "Invalid.\n";
        return;
    }

    Document *doc = f->createInstance(kind);
    if (doc)
        doc->print();
    delete doc;
    delete f;
}

// =============================================================================
// Menu 7 — Legacy adapter
// =============================================================================
static void menuLegacySync()
{
    heading("Sync application to legacy student records system");
    LegacyiHookAPI legacy;
    LegacyiHookAdapter adapter(&legacy);

    std::map<std::string, std::string> payload;
    payload["studentNumber"] = "u24986535";
    payload["studentName"] = "Lethukuthula Ngwenya";
    payload["programme"] = "BSc Computer Science";
    payload["aps"] = "40";
    payload["englishLevel"] = "6";
    payload["decision"] = "OFFER";
    payload["faculty"] = "Science";
    adapter.sendPayload(payload);
}

// =============================================================================
// Menu 8 — Metrics
// =============================================================================
static void menuMetrics()
{
    heading("Admissions metrics");
    MetricsReportVisitor visitor;
    gEngine.exportMetrics(&visitor);
    visitor.displayMetrics();
}

// =============================================================================
// Menu
// =============================================================================
static void printMenu()
{
    rule();
    std::cout << "  TIVIDY University Admissions System (South Africa)\n";
    rule();
    std::cout << "  1. Start a new application\n"
              << "  2. Inspect an application\n"
              << "  3. Take an action\n"
              << "  4. Record a decision\n"
              << "  5. View / roll back history\n"
              << "  6. Generate university documents (both industries)\n"
              << "  7. Sync to legacy student records\n"
              << "  8. Export admissions metrics\n"
              << "  0. Exit\n";
    rule();
}

// =============================================================================
int main()
{
    std::cout << "\nWelcome to the TIVIDY University Admissions System.\n"
              << "(South African NSC system — APS out of 42, English level 1-7)\n\n";
    seedDefinitions();

    bool running = true;
    while (running)
    {
        printMenu();
        int choice = askInt("Choice: ");
        switch (choice)
        {
        case 1:
            menuStart();
            break;
        case 2:
            menuInspect();
            break;
        case 3:
            menuExecute();
            break;
        case 4:
            menuDecision();
            break;
        case 5:
            menuHistory();
            break;
        case 6:
            menuDocuments();
            break;
        case 7:
            menuLegacySync();
            break;
        case 8:
            menuMetrics();
            break;
        case 0:
            running = false;
            break;
        default:
            std::cout << "Unknown option.\n";
            break;
        }
    }

    for (size_t i = 0; i < gObservers.size(); ++i)
        delete gObservers[i];
    gObservers.clear();

    std::cout << "Goodbye.\n";
    return 0;
}